// Script desativado - Registro removido.
console.log("Cadastro removido.");