// Script desativado - Sistema de autenticação removido para foco em Landing Page.
console.log("Portal de Cursos Ativo.");